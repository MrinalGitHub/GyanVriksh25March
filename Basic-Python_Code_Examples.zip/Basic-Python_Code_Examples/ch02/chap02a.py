#!/usr/bin/python

name = input("Enter your name NOW!!!!: \n")
print ("Hello", name)

hours = input("Enter hours : \n")
rate = input("Enter your rate: \n")
x = (float(hours) * float(rate))
print ("Pay:", x)


